#include <iostream>
#include <cstring>
#include <fstream>

using namespace std;

void getCode(char code[1000]);
int  getParagraph(char paragraph[1000]);
void getLength(char code[1000], int& wholelen);
void convertString(char code[1000], int wholelen, char newcode[1000]);
void mixCode(char newcode[1000], int wholelen, char paragraph[1000]);
void outputFile(char paragraph[1000]);

int main ()


{
      char        code[1000]; 
      int         wholelen = 0;
      char        newcode[100];
      char        paragraph[1000]; 

      getCode(code);
      
      getLength(code, wholelen);
      
      convertString(code, wholelen, newcode);
      
      if(getParagraph(paragraph))
      {
      mixCode(newcode, wholelen, paragraph);

      outputFile(paragraph);
      }

      else {
            return 0;
            }
}

void getCode(char code[1000])

{        
      char newcode[1000]; 
   
      cout << "Enter the secret code, no more than 100 characters, then hit enter: ";
      cin.get (code, 100, '\n');
      cin.get();
       
}

int getParagraph(char paragraph[1000])

{

      ifstream    infile;
      char        filearray[30];

      cout << "Enter the name of the file to be read:  ";
      cin >> filearray;
      cin.ignore(100, '\n');
      cout << endl;

      infile.open(filearray);
         if(!infile){
         cout << "Error: File could not be opened!" << endl;
         return 0;
         }
      if (!infile.eof())
    {     for(int i = 0; i < 1000; ++i)
        {
            infile.get(paragraph[i]);
        }
    } 
      infile.close();

}

void getLength(char code[1000], int &wholelen)

{
      wholelen = strlen(code);   

}      
                  
void convertString(char code[1000], int wholelen, char newcode[1000])

{          
      char next;
     
      for (int i = 0; i < wholelen; i++)
         {
            if (code[i] == ' '){
               next = code[i + 1]; 
               if (next >= 'a' && next <= 'z'){
                next += ('A' - 'a');
                code[i + 1] = next;     
               }
            } //end if loop 
         newcode[i] = code[i];
        } // end for loop       
}

void mixCode(char newcode[1000], int wholelen, char paragraph[1000])

{
     int    graphlen;
     int    j = 1;
     graphlen = strlen(paragraph);

        paragraph[0] = newcode [0];
        while (j < wholelen)    
            for(int i = 1; i < graphlen + 1; i++)
            {  
               if(paragraph[i] == ' ')
                  {
                     paragraph[i+1] = newcode[j];
                     j++;
                 }
            }
}        

void outputFile(char paragraph[1000])

{
      ofstream outfile;
      char     outarray[30];

      cout << "Enter the name of the output file:  ";
      cin >> outarray;
      outfile.open(outarray);
      outfile << paragraph;
      outfile.close();   
}
   


 
      
      
